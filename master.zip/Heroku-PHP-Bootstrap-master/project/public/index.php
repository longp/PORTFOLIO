<?php

echo 'Your journey has just begun.';
