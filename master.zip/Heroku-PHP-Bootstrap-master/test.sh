#! /usr/bin/env bash

bash -n project/bootstrap.sh